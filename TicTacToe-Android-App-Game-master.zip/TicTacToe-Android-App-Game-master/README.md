# tictactoe

This is a simple tictactoe where two players can play. There is no minimax algorithm implemented.

1. Download this
2. Import it using Android Studio

## Explanation
A step by step explanation of this project can be found [here](http://hubpages.com/technology/tictactoe)

[By Nabin Khadka](https://www.nabinkhadka.com.np "Nabin's Homepage")
